<!DOCTYPE html>









	



	
	




	<meta name="apple-mobile-web-app-title" content="Ghosted">
	


	
	


















	



















	











	

































	



































































<html id="XF" lang="en-US" dir="LTR"
	  style="font-size: 62.5%;"
	  data-app="public"
	  data-template="login"
	  data-container-key=""
	  data-content-key=""
	  data-logged-in="false"
	  data-cookie-prefix="xf_"
	  data-csrf="1656157378,1c44c82087ba25f22f2656af15e319c0"
	  class="has-no-js template-login  uix_hasBottomTabs uix_page--fixed "
	   data-run-jobs="">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">

		

		<title>Log in | Ghosted</title>
		<link rel="manifest" href="/forum/webmanifest.php">
		
			<meta name="theme-color" content="#432370" />
			<meta name="msapplication-TileColor" content="#432370">
		
		<meta name="apple-mobile-web-app-title" content="Ghosted">
		

		
			<meta name="robots" content="noindex" />
		

		
			
	
	
	<meta property="og:site_name" content="Ghosted" />


		
		
			
	
	
	<meta property="og:type" content="website" />


		
		
			
	
	
	
		<meta property="og:title" content="Log in" />
		<meta property="twitter:title" content="Log in" />
	


		
		
		
			
	
	
	<meta property="og:url" content="http://ghosted.vip/forum/index.php" />


		
		

		
	

	

	
		
	

	<link rel="stylesheet" href="/forum/css.php?css=public%3Anormalize.css%2Cpublic%3Afa.css%2Cpublic%3Acore.less%2Cpublic%3Aapp.less&amp;s=2&amp;l=1&amp;d=1654794136&amp;k=a082e7e7a4cdd636d922f7188bc91765201e601b" />

	
		<link rel="preload" href="/forum/styles/io_dark/fonts/icons/material-icons/fonts/materialdesignicons-webfont.woff2?v=5.8.55" as="font" type="font/woff2" crossorigin="anonymous" />
		<link rel="stylesheet" href="/forum/styles/io_dark/fonts/icons/material-icons/css/materialdesignicons.min.css?d=1654261577" />	
	

	
	
	
		
	
		
	

	<link rel="stylesheet" href="/forum/css.php?css=public%3Aio.less%2Cpublic%3Aiodark.less%2Cpublic%3Anotices.less%2Cpublic%3Auix.less%2Cpublic%3Auix_socialMedia.less%2Cpublic%3Aextra.less&amp;s=2&amp;l=1&amp;d=1654794136&amp;k=4365689e7e6f83bfa90b53bcd822c4fafd68b49c" />

	
	
		<script src="/forum/js/xf/preamble.min.js?_v=a146e845"></script>
	
	
	<meta name="apple-mobile-web-app-capable" content="yes">


		
			<link rel="icon" type="image/png" href="http://ghosted.vip/forum/styles/io_dark/images/favicon.png" sizes="32x32" />
		
		
		

		

		

	</head>

	<body data-template="login">
		<style>
	.p-pageWrapper .p-navSticky {
		top: 0 !important;
	}

	

	
	

	
	
	
		
			
			
				
			
		
	

	

	
		
	

		
		
		.uix_mainTabBar {top: 65px !important;}
		.uix_stickyBodyElement:not(.offCanvasMenu) {
			top: 85px !important;
			min-height: calc(100vh - 85px) !important;
		}
		.uix_sidebarInner .uix_sidebar--scroller {margin-top: 85px;}
		.uix_sidebarInner {margin-top: -85px;}
		.p-body-sideNavInner .uix_sidebar--scroller {margin-top: 85px;}
		.p-body-sideNavInner {margin-top: -85px;}
		.uix_stickyCategoryStrips {top: 85px !important;}
		#XF .u-anchorTarget {
			height: 85px;
			margin-top: -85px;
		}
	
		

		
			@media (max-width: $uix_sidebarBreakpoint) {
		
				.p-sectionLinks {display: none;}

				

				.uix_mainTabBar {top: 65px !important;}
				.uix_stickyBodyElement:not(.offCanvasMenu) {
					top: 85px !important;
					min-height: calc(100vh - 85px) !important;
				}
				.uix_sidebarInner .uix_sidebar--scroller {margin-top: 85px;}
				.uix_sidebarInner {margin-top: -85px;}
				.p-body-sideNavInner .uix_sidebar--scroller {margin-top: 85px;}
				.p-body-sideNavInner {margin-top: -85px;}
				.uix_stickyCategoryStrips {top: 85px !important;}
				#XF .u-anchorTarget {
					height: 85px;
					margin-top: -85px;
				}

				
		
			}
		
	

	.uix_sidebarNav .uix_sidebar--scroller {max-height: calc(100vh - 85px);}
	
	
</style>


		<div id="jumpToTop"></div>

		

		<div class="uix_pageWrapper--fixed">
			<div class="p-pageWrapper" id="top">

				
					
	
	



					

					

					
						
						
							<header class="p-header" id="header">
								<div class="p-header-inner">
									
						
							<div class="p-header-content">
								
									
										
	
	<div class="p-header-logo p-header-logo--image">
		<a class="uix_logo" href="https://ghosted.vip">
			
				<img src="/forum/styles/io_dark/io/images/logo.png" srcset="" alt="Ghosted"
					 width="" height="" />
				
		</a>
		
			<a class="uix_logoSmall" href="https://ghosted.vip">
				<img src="/forum/styles/io_dark/images/uix-brandmark.png"
					 alt="Ghosted"
					 />
			</a>
		
	</div>


									

									
								
							</div>
						
					
								</div>
							</header>
						
					
					

					
					
					

					
						<div class="p-navSticky p-navSticky--all " data-top-offset-breakpoints="
						[
							{
								&quot;breakpoint&quot;: &quot;0&quot;,
								&quot;offset&quot;: &quot;0&quot;
							}
							
							
						]
					" data-xf-init="sticky-header">
							
						<nav class="p-nav">
							<div class="p-nav-inner">
								
									
									
										
									
									<button type="button" class="button--plain p-nav-menuTrigger  badgeContainer button" data-badge="0" data-xf-click="off-canvas" data-menu=".js-headerOffCanvasMenu" role="button" tabindex="0" aria-label="Menu"><span class="button-text">
										<i aria-hidden="true"></i>
									</span></button>
									
								

								
	
	<div class="p-header-logo p-header-logo--image">
		<a class="uix_logo" href="https://ghosted.vip">
			
				<img src="/forum/styles/io_dark/io/images/logo.png" srcset="" alt="Ghosted"
					 width="" height="" />
				
		</a>
		
			<a class="uix_logoSmall" href="https://ghosted.vip">
				<img src="/forum/styles/io_dark/images/uix-brandmark.png"
					 alt="Ghosted"
					 />
			</a>
		
	</div>



								
									
										<div class="p-nav-scroller hScroller" data-xf-init="h-scroller" data-auto-scroll=".p-navEl.is-selected">
											<div class="hScroller-scroll">
												<ul class="p-nav-list js-offCanvasNavSource">
													
														<li>
															
	<div class="p-navEl u-ripple " >
		
			
				
	
	<a href="https://ghosted.vip"
			class="p-navEl-link  "
			
			data-xf-key="1"
			data-nav-id="home"><span>Home</span></a>

				
				
			
			
			
		
			
	
</div>

														</li>
													
														<li>
															
	<div class="p-navEl u-ripple " data-has-children="true">
		
			
				
	
	<a href="/forum/index.php"
			class="p-navEl-link p-navEl-link--splitMenu "
			
			
			data-nav-id="forums"><span>Forums</span></a>

				
					<a data-xf-key="2"
					   data-xf-click="menu"
					   data-menu-pos-ref="< .p-navEl"
					   class="p-navEl-splitTrigger"
					   role="button"
					   tabindex="0"
					   aria-label="Toggle expanded"
					   aria-expanded="false"
					   aria-haspopup="true">
					</a>
				
				
			
				
					<div class="menu menu--structural" data-menu="menu" aria-hidden="true">
						<div class="menu-content">
							
								
	
	
	<a href="/forum/index.php?whats-new/posts/"
			class="menu-linkRow u-ripple u-indentDepth0 js-offCanvasCopy "
			
			
			data-nav-id="newPosts"><span>New posts</span></a>

	

							
						</div>
					</div>
				
			
			
			
		
			
	
</div>

														</li>
													
														<li>
															
	<div class="p-navEl u-ripple " data-has-children="true">
		
			
				
	
	<a href="/forum/index.php?whats-new/"
			class="p-navEl-link p-navEl-link--splitMenu "
			
			
			data-nav-id="whatsNew"><span>What's new</span></a>

				
					<a data-xf-key="3"
					   data-xf-click="menu"
					   data-menu-pos-ref="< .p-navEl"
					   class="p-navEl-splitTrigger"
					   role="button"
					   tabindex="0"
					   aria-label="Toggle expanded"
					   aria-expanded="false"
					   aria-haspopup="true">
					</a>
				
				
			
				
					<div class="menu menu--structural" data-menu="menu" aria-hidden="true">
						<div class="menu-content">
							
								
	
	
	<a href="/forum/index.php?whats-new/posts/"
			class="menu-linkRow u-ripple u-indentDepth0 js-offCanvasCopy "
			 rel="nofollow"
			
			data-nav-id="whatsNewPosts"><span>New posts</span></a>

	

							
								
	
	
	<a href="/forum/index.php?whats-new/latest-activity"
			class="menu-linkRow u-ripple u-indentDepth0 js-offCanvasCopy "
			 rel="nofollow"
			
			data-nav-id="latestActivity"><span>Latest activity</span></a>

	

							
						</div>
					</div>
				
			
			
			
		
			
	
</div>

														</li>
													
														<li>
															
	<div class="p-navEl u-ripple " >
		
			
				
	
	<a href="https://shoppy.gg/@Ghosted.vip"
			class="p-navEl-link  "
			
			data-xf-key="4"
			data-nav-id="store"><span>Shop</span></a>

				
				
			
			
			
		
			
	
</div>

														</li>
													
												</ul>
											</div>
										</div>
									

									
								

								
	


								
									<div class="p-nav-opposite">
										
											
		
			
				
					<div class="p-navgroup p-account p-navgroup--guest">
						
							
								
	
		
		
	
	
		
			<a href="/forum/index.php?register/" class="p-navgroup-link u-ripple p-navgroup-link--textual p-navgroup-link--register" data-xf-click="overlay" data-follow-redirects="on">
				<i></i>
				<span class="p-navgroup-linkText">Register</span>
			</a>
		
	

	

							
						
					</div>
				
				
				
	

			
		
	
											
	
		
	

	

										
									</div>
								
							</div>
							
						</nav>
					
							
		
			<div class="p-sectionLinks p-sectionLinks--empty"></div>
		
	
						</div>
						

					

					
	

					
	

					
	

					
	

					
				

				
				<div class="offCanvasMenu offCanvasMenu--nav js-headerOffCanvasMenu" data-menu="menu" aria-hidden="true" data-ocm-builder="navigation">
					<div class="offCanvasMenu-backdrop" data-menu-close="true"></div>
					<div class="offCanvasMenu-content">
						
						<div class="sidePanel sidePanel--nav sidePanel--visitor">
	<div class="sidePanel__tabPanels">
		
		<div data-content="navigation" class="is-active sidePanel__tabPanel js-navigationTabPanel">
			
							<div class="offCanvasMenu-header">
								Menu
								<a class="offCanvasMenu-closer" data-menu-close="true" role="button" tabindex="0" aria-label="Close"></a>
							</div>
							
							<div class="js-offCanvasNavTarget"></div>
							
							
						
		</div>
		
		
		
	</div>
</div>

						
						<div class="offCanvasMenu-installBanner js-installPromptContainer" style="display: none;" data-xf-init="install-prompt">
							<div class="offCanvasMenu-installBanner-header">Install the app</div>
							<button type="button" class="js-installPromptButton button"><span class="button-text">Install</span></button>
						</div>
					</div>
				</div>

				
	
		
	
		
			<div class="p-body-header">
				<div class="pageContent">
					
						
							<div class="uix_headerInner">
								
									
										<div class="p-title ">
											
												
													<h1 class="p-title-value">Log in</h1>
												
											
										</div>
									

									
								
							</div>
						
						
					
				</div>
			</div>
		
	

	


				<div class="p-body">

					

					<div class="p-body-inner ">
						
						<!--XF:EXTRA_OUTPUT-->

						
	
		
	
		
			
	
		
		
		

		<ul class="notices notices--block  js-notices"
			data-xf-init="notices"
			data-type="block"
			data-scroll-interval="6">

			
				
	<li class="notice js-notice notice--primary"
		data-notice-id="1"
		data-delay-duration="0"
		data-display-duration="0"
		data-auto-dismiss=""
		data-visibility="">
		
		<div class="uix_noticeInner">
			
			<div class="uix_noticeIcon">
				
					<i class="fa--xf far fa-info-circle" aria-hidden="true"></i>
				
			</div>

			
			<div class="notice-content">
				
					<a href="/forum/index.php?account/dismiss-notice&amp;notice_id=1" class="notice-dismiss js-noticeDismiss" data-xf-init="tooltip" title="Dismiss notice"></a>
				
				If you dont associate your Discord account within 3 days You will be banned.
			</div>
		</div>
	</li>

			
		</ul>
	

		

		
	

	


						
	


						
	


						
	
		
	
	
	

	

	


						
	


						
	<noscript class="js-jsWarning"><div class="blockMessage blockMessage--important blockMessage--iconic u-noJsOnly">JavaScript is disabled. For a better experience, please enable JavaScript in your browser before proceeding.</div></noscript>

						
	<div class="blockMessage blockMessage--important blockMessage--iconic js-browserWarning" style="display: none">You are using an out of date browser. It  may not display this or other websites correctly.<br />You should upgrade or use an <a href="https://www.google.com/chrome/" target="_blank" rel="noopener">alternative browser</a>.</div>



						<div uix_component="MainContainer" class="uix_contentWrapper">

							
	


							
							
	

							
	

							
	

							
	


							<div class="p-body-main  ">
								
								

								
	

								<div uix_component="MainContent" class="p-body-content">
									<!-- ABOVE MAIN CONTENT -->
									
	

									
	

									
	

									
	

									
	

									<div class="p-body-pageContent">
										
	

										
	

										
	

										
	

										
	

										









	<div class="blockMessage blockMessage--error blockMessage--iconic">
		You must be logged-in to do that.
	</div>


<div class="blocks">
	
			<form action="/forum/index.php?login/login" method="post" class="block"
				
			>
				<input type="hidden" name="_xfToken" value="1656157378,1c44c82087ba25f22f2656af15e319c0" />
				
		<div class="block-container">
			<div class="block-body">
				
					
			<dl class="formRow formRow--input">
				<dt>
					<div class="formRow-labelWrapper">
					<label class="formRow-label" for="_xfUid-1-1656157378">Your name or email address</label></div>
				</dt>
				<dd>
					<input type="text" class="input" name="login" autofocus="autofocus" autocomplete="username" id="_xfUid-1-1656157378" />
				</dd>
			</dl>
		
				

				
			<dl class="formRow formRow--input">
				<dt>
					<div class="formRow-labelWrapper">
					<label class="formRow-label" for="_xfUid-2-1656157378">Password</label></div>
				</dt>
				<dd>
					



<div data-xf-init=" password-hide-show"
	data-show-text="Show" data-hide-text="Hide">
	
		<div class="inputGroup inputGroup--joined">
			
	<input type="password" name="password" value=""
		class="input js-password input--passwordHideShow"  autocomplete="current-password" id="_xfUid-2-1656157378" />

			
			<div class="inputGroup-text">
				<label class="iconic iconic--hideShow js-hideShowContainer"><input type="checkbox"  value="1" /><i aria-hidden="true"></i><span class="iconic-label">Show</span></label>

			</div>
		</div>
	

	
</div>
					<a class="uix_forgotPassWord__link" href="/forum/index.php?lost-password/" data-xf-click="overlay">Forgot your password?</a>
				</dd>
			</dl>
		

				

				
			<dl class="formRow">
				<dt>
					<div class="formRow-labelWrapper"></div>
				</dt>
				<dd>
					
			<ul class="inputChoices">
				<li class="inputChoices-choice"><label class="iconic"><input type="checkbox"  name="remember" value="1" checked="checked" /><i aria-hidden="true"></i><span class="iconic-label">Stay logged in</span></label></li>

			</ul>
		
				</dd>
			</dl>
		

				<input type="hidden" name="_xfRedirect" value="" />
			</div>
			
			<dl class="formRow formSubmitRow">
				<dt></dt>
				<dd>
					<div class="formSubmitRow-main">
						<div class="formSubmitRow-bar"></div>
						<div class="formSubmitRow-controls"><button type="submit" class="button--primary button button--icon button--icon--login"><span class="button-text">Log in</span></button></div>
					</div>
				</dd>
			</dl>
		
		</div>
		
			<div class="block-outer block-outer--after uix_login__registerLink">
				<div class="block-outer-middle">
					Don't have an account? <a href="/forum/index.php?register/">Register now</a>
				</div>
			</div>
		
	
				
			</form>
		

	
		<div class="blocks-textJoiner"><span></span><em>or Log in using</em><span></span></div>

		<div class="block uix_loginProvider__row">
			<div class="block-container">
				<div class="block-body">
					
			<dl class="formRow formRow--button">
				<dt>
					<div class="formRow-labelWrapper"></div>
				</dt>
				<dd>
					
						<ul class="listHeap">
							
								<li>
									
	<a href="/forum/index.php?register/connected-accounts/ewr_discord/&amp;setup=1" class="button--provider button--provider--ewr_discord button"><span class="button-text">
		
		Discord
	</span></a>

								</li>
							
						</ul>
					
				</dd>
			</dl>
		
				</div>
			</div>
		</div>
	
</div>
										
	

									</div>
									<!-- BELOW MAIN CONTENT -->
									
									
	

								</div>

								
	
		
	

	

							</div>
							
	

						</div>
						
	
		
	
		
		
	

		
	

	

						
	

					</div>
				</div>

				
	
		
	<footer class="p-footer" id="footer">

		

		<div class="p-footer-inner">
			<div class="pageContent">
				<div class="p-footer-row">
					
						<div class="p-footer-row-main">
							<ul class="p-footer-linkList p-footer-choosers">
								
									
										<li><a id="uix_widthToggle--trigger" data-xf-init="tooltip" title="Toggle width" rel="nofollow"><i class="fa--xf far fa-compress-alt" aria-hidden="true"></i></a></li>
									
									
										<li><a href="/forum/index.php?misc/style" data-xf-click="overlay" data-xf-init="tooltip" title="Style chooser" rel="nofollow">iO Dark Mode</a></li>
									
									
								
							</ul>
						</div>
					
				</div>
				<div class="p-footer-row-opposite">
					<ul class="p-footer-linkList">
						

						
							<li><a href="/forum/index.php?help/terms/">Terms and rules</a></li>
						

						
							<li><a href="/forum/index.php?help/privacy-policy/">Privacy policy</a></li>
						

						
							<li><a href="/forum/index.php?help/">Help</a></li>
						

						
							<li><a href="https://ghosted.vip">Home</a></li>
						

						<li><a href="#top" title="Top" data-xf-click="scroll-to"><i class="fa fa-arrow-up" aria-hidden="true"></i></a></li>

						<li><a href="/forum/index.php?forums/-/index.rss" target="_blank" class="p-footer-rssLink" title="RSS"><span aria-hidden="true"><i class="fa fa-rss"></i><span class="u-srOnly">RSS</span></span></a></li>
					</ul>
				</div>
			</div>
		</div>

		<div class="p-footer-copyrightRow">
			<div class="pageContent">
				<div class="uix_copyrightBlock">
					
						<div class="p-footer-copyright">
							
								Community platform by XenForo<sup>&reg;</sup> <span class="copyright">&copy; 2010-2022 XenForo Ltd.</span>
								<span class="thBranding"><span class="thBranding__pipe"> | </span><a href="https://www.themehouse.com/?utm_source=ghosted.vip&utm_medium=xf2product&utm_campaign=product_branding" class="u-concealed" target="_BLANK" nofollow="nofollow">Style by ThemeHouse</a></span>
								
<div class="discord-copyright">
	<a href="https://xenforo.com/community/resources/6058/"
		target="_blank">Discord Integration</a> &copy; Jason Axelrod of
	<a href="https://8wayrun.com/" target="_blank">8WAYRUN</a>
</div>
							
						</div>
					

					
				</div>
				
	
		
	


	

			</div>
		</div>
	</footer>

	


				
					<div class="uix_fabBar uix_fabBar--active">
						
							
								<div class="u-scrollButtons js-scrollButtons" data-trigger-type="both">
									<a href="#top" class="button--scroll ripple-JsOnly button" data-xf-click="scroll-to"><span class="button-text"><i class="fa--xf far fa-arrow-up" aria-hidden="true"></i><span class="u-srOnly">Top</span></span></a>
									
										<a href="#footer" class="button--scroll ripple-JsOnly button" data-xf-click="scroll-to"><span class="button-text"><i class="fa--xf far fa-arrow-down" aria-hidden="true"></i><span class="u-srOnly">Bottom</span></span></a>
									
								</div>
							
							
						
					</div>
				
				
				
					
	

				
			</div>
		</div>

		<div class="u-bottomFixer js-bottomFixTarget">
			
			
		</div>

		<script>
	if (typeof (window.themehouse) !== 'object') {
		window.themehouse = {};
	}
	if (typeof (window.themehouse.settings) !== 'object') {
		window.themehouse.settings = {};
	}
	window.themehouse.settings = {
		common: {
			'20210125': {
				init: false,
			},
		},
		data: {
			version: '2.2.8.1.0',
			jsVersion: 'No JS Files',
			templateVersion: '2.1.8.0_Release',
			betaMode: 0,
			theme: '',
			url: 'http://ghosted.vip/forum/',
			user: '0',
		},
		inputSync: {},
		minimalSearch: {
			breakpoint: "10000px",
			dropdownBreakpoint: "10000",
		},
		sidebar: {
            enabled: '1',
			link: '/forum/index.php?uix/toggle-sidebar.json&amp;t=1656157378%2C1c44c82087ba25f22f2656af15e319c0',
            state: '',
		},
        sidebarNav: {
            enabled: '',
			link: '/forum/index.php?uix/toggle-sidebar-navigation.json&amp;t=1656157378%2C1c44c82087ba25f22f2656af15e319c0',
            state: '',
		},
		fab: {
			enabled: 1,
		},
		checkRadius: {
			enabled: 0,
			selectors: '.p-footer-inner, .uix_extendedFooter, .p-nav, .p-sectionLinks, .p-staffBar, .p-header, #wpadminbar',
		},
		nodes: {
			enabled: 1,
		},
        nodesCollapse: {
            enabled: '1',
			link: '/forum/index.php?uix/toggle-category.json&amp;t=1656157378%2C1c44c82087ba25f22f2656af15e319c0',
			state: '',
        },
		widthToggle: {
			enabled: '1',
			link: '/forum/index.php?uix/toggle-width.json&amp;t=1656157378%2C1c44c82087ba25f22f2656af15e319c0',
			state: 'fixed',
		},
	}

	window.document.addEventListener('DOMContentLoaded', function() {
		
			try {
			   window.themehouse.common['20210125'].init();
			   window.themehouse.common['20180112'] = window.themehouse.common['20210125']; // custom projects fallback
			} catch(e) {
			   console.log('Error caught', e);
			}
		


		var jsVersionPrefix = 'No JS Files';
		if (typeof(window.themehouse.settings.data.jsVersion) === 'string') {
			var jsVersionSplit = window.themehouse.settings.data.jsVersion.split('_');
			if (jsVersionSplit.length) {
				jsVersionPrefix = jsVersionSplit[0];
			}
		}
		var templateVersionPrefix = 'No JS Template Version';
		if (typeof(window.themehouse.settings.data.templateVersion) === 'string') {
			var templateVersionSplit = window.themehouse.settings.data.templateVersion.split('_');
			if (templateVersionSplit.length) {
				templateVersionPrefix = templateVersionSplit[0];
			}
		}
		if (jsVersionPrefix !== templateVersionPrefix) {
			var splitFileVersion = jsVersionPrefix.split('.');
			var splitTemplateVersion = templateVersionPrefix.split('.');
			console.log('version mismatch', jsVersionPrefix, templateVersionPrefix);
		}

	});
</script>

		
	<script src="/forum/js/vendor/jquery/jquery-3.5.1.min.js?_v=a146e845"></script>
	<script src="/forum/js/vendor/vendor-compiled.js?_v=a146e845"></script>
	<script src="/forum/js/xf/core-compiled.js?_v=a146e845"></script>
	<script src="/forum/js/xf/login_signup.min.js?_v=a146e845"></script>
<script src="/forum/js/xf/notice.min.js?_v=a146e845"></script>
<script src="/forum/js/themehouse/io_dark/ripple.min.js?_v=a146e845"></script>
<script src="/forum/js/themehouse/global/20210125.min.js?_v=a146e845"></script>
<script src="/forum/js/themehouse/io_dark/index.min.js?_v=a146e845"></script>
<script src="/forum/js/themehouse/io_dark/vendor/hover-intent/jquery.hoverIntent.min.js?_v=a146e845"></script>
<script>

	// detect android device. Added to fix the dark pixel bug https://github.com/Audentio/xf2theme-issues/issues/1055

	$(document).ready(function() {
	var ua = navigator.userAgent.toLowerCase();
	var isAndroid = ua.indexOf("android") > -1; //&& ua.indexOf("mobile");

	if(isAndroid) {
	$('html').addClass('device--isAndroid');
	}	
	})

</script>
<script>

		$(document).ready(function() {
		$('.structItem--thread').bind('click', function(e) {
		var target = $(e.target);
		var skip = ['a', 'i', 'input', 'label'];
		if (target.length && skip.indexOf(target[0].tagName.toLowerCase()) === -1) {
		var href = $(this).find('.structItem-title').attr('uix-href');
		if (e.metaKey || e.cmdKey) {
		e.preventDefault();
		window.open(href, '_blank');
		} else {
		window.location = href;
		}
		}
		});
		});
	
</script>
<script>

		$(document).ready(function() {
		var sidebar = $('.p-body-sidebar');
		var backdrop = $('.p-body-sidebar [data-ocm-class="offCanvasMenu-backdrop"]');

		$('.uix_sidebarCanvasTrigger').click(function(e) {
		e.preventDefault();

			sidebar.css('display', 'block');
			window.setTimeout(function() {
				sidebar.addClass('offCanvasMenu offCanvasMenu--blocks is-active is-transitioning');
				$('body').addClass('sideNav--open');
		}, 50);

		window.setTimeout(function() {
		sidebar.removeClass('is-transitioning');
		}, 250);

		$('.uix_sidebarInner').addClass('offCanvasMenu-content');
		backdrop.addClass('offCanvasMenu-backdrop');
		$('body').addClass('is-modalOpen');
		});

		backdrop.click(function() {
			sidebar.addClass('is-transitioning');
			sidebar.removeClass('is-active');

			window.setTimeout(function() {
				sidebar.removeClass('offCanvasMenu offCanvasMenu--blocks is-transitioning');
				$('.uix_sidebarInner').removeClass('offCanvasMenu-content');
				backdrop.removeClass('offCanvasMenu-backdrop');
				$('body').removeClass('is-modalOpen');
				sidebar.css('display', '');
				}, 250);
			})
		});
	
</script>
<script>

	/****** OFF CANVAS ***/
	$(document).ready(function() {
	var panels = {
	navigation: {
	position: 1
	},
	account: {
	position: 2
	},
	inbox: {
	position: 3
	},
	alerts: {
	position: 4
	}
	};


	var tabsContainer = $('.sidePanel__tabs');

	var activeTab = 'navigation';

	var activeTabPosition = panels[activeTab].position;

	var generateDirections = function() {
	$('.sidePanel__tabPanel').each(function() {
	var tabPosition = $(this).attr('data-content');
	var activeTabPosition = panels[activeTab].position;

	if (tabPosition != activeTab) {
	if (panels[tabPosition].position < activeTabPosition) {
														 $(this).addClass('is-left');
														 }

														 if (panels[tabPosition].position > activeTabPosition) {
	$(this).addClass('is-right');
	}
	}
	});
	};

	generateDirections();

	$('.sidePanel__tab').click(function() {
	$(tabsContainer).find('.sidePanel__tab').removeClass('sidePanel__tab--active');
	$(this).addClass('sidePanel__tab--active');

	activeTab = $(this).attr('data-attr');

	$('.sidePanel__tabPanel').removeClass('is-active');

	$('.sidePanel__tabPanel[data-content="' + activeTab + '"]').addClass('is-active');
	$('.sidePanel__tabPanel').removeClass('is-left').removeClass('is-right');
	generateDirections();
	});
	});

	/******** extra info post toggle ***********/

	$(document).ready(function() {
	XF.thThreadsUserExtraTrigger = XF.Click.newHandler({
	eventNameSpace: 'XFthThreadsUserExtraTrigger',

	init: function(e) {},

	click: function(e)
	{
	var parent =  this.$target.parents('.message-user');
	var triggerContainer = this.$target.parent('.thThreads__userExtra--toggle');
	var container = triggerContainer.siblings('.thThreads__message-userExtras');
	var child = container.find('.message-userExtras');
	var eleHeight = child.height();
	if (parent.hasClass('userExtra--expand')) {
	container.css({ height: eleHeight });
	parent.toggleClass('userExtra--expand');
	window.setTimeout(function() {
	container.css({ height: '0' });
	window.setTimeout(function() {
	container.css({ height: '' });
	}, 200);
	}, 17);

	} else {
	container.css({ height: eleHeight });
	window.setTimeout(function() {
	parent.toggleClass('userExtra--expand');
	container.css({ height: '' });
	}, 200);
	}
	}
	});

	XF.Click.register('ththreads-userextra-trigger', 'XF.thThreadsUserExtraTrigger');
	});

	/******** Backstretch images ***********/

	$(document).ready(function() {
	if ( 0 ) {

	$("body").addClass('uix__hasBackstretch');

	$("body").backstretch([
	"/forum/styles/io_dark/images/bg/1.jpg","/forum/styles/io_dark/images/bg/2.jpg","/forum/styles/io_dark/images/bg/3.jpg"
	], {
	duration: 4000,
	fade: 500
	});

	$("body").css("zIndex","");
	}
	});

	// sidenav canvas blur fix

	$(document).ready(function(){
	$('.p-body-sideNavTrigger .button').click(function(){
	$('body').addClass('sideNav--open');
	});
	})

	$(document).ready(function(){
	$("[data-ocm-class='offCanvasMenu-backdrop']").click(function(){
	$('body').removeClass('sideNav--open');
	});
	})

	$(document).on('editor:start', function (m, ed) {
	if (typeof (m) !== 'undefined' && typeof (m.target) !== 'undefined') {
	var ele = $(m.target);
	if (ele.hasClass('js-editor')) {
	var wrapper = ele.closest('.message-editorWrapper');
	if (wrapper.length) {
	window.setTimeout(function() {
	var innerEle = wrapper.find('.fr-element');
	if (innerEle.length) {
	innerEle.focus(function (e) {
	$('html').addClass('uix_editor--focused')
	});
	innerEle.blur(function (e) {
	$('html').removeClass('uix_editor--focused')
	});
	}
	}, 0);
	}
	}
	}
	});

	// off canvas menu closer keyboard shortcut
	$(document).ready(function() {
	$(document.body).onPassive('keyup', function(e) {
	switch (e.key) {
	case 'Escape':
	$('.offCanvasMenu.is-active .offCanvasMenu-backdrop').click();
	return;
	}
	});
	});
	
</script>
<script>

		$(document).ready(function() {
		var uixMegaHovered = false;
		$('.uix-navEl--hasMegaMenu').hoverIntent({
		over: function() {
		if (uixMegaHovered) {
		menu = $(this).attr('data-nav-id');

		$('.p-nav').addClass('uix_showMegaMenu');

		$('.uix_megaMenu__content').removeClass('uix_megaMenu__content--active');

		$('.uix_megaMenu__content--' + menu).addClass('uix_megaMenu__content--active');
		}
		},
		timeout: 200,
		});

		$('.p-nav').mouseenter(function() {
		uixMegaHovered = true;
		});

		$('.p-nav').mouseleave(function() {
		$(this).removeClass('uix_showMegaMenu');
		uixMegaHovered = false;
		});
		});
	
</script>
<script>

			/******** signature collapse toggle ***********/
			$(window).on('load', function() {
			window.setTimeout(function() {
			var maxHeight = 100;

			/*** check if expandable ***/
			var eles = [];

			$('.message-signature').each(function() {
			var height = $(this).height();
			if (height > maxHeight) {
			eles.push($(this));
			}
			});

			for (var i = 0; i < eles.length; i++) {
											eles[i].addClass('message-signature--expandable');
											};

											/**** expand function ***/
											var expand = function(container, canClose) {
											var inner = container.find('.bbWrapper');
											var eleHeight = inner.height();
											var isExpanded = container.hasClass('message-signature--expanded');

											if (isExpanded) {
											if (canClose) {
											container.css({ height: eleHeight });
											container.removeClass('message-signature--expanded');
											window.setTimeout(function() {
											container.css({ height: maxHeight });
											window.setTimeout(function() {
											container.css({ height: '' });
											}, 200);
											}, 17);					
											}

											} else {
											container.css({ height: eleHeight });
											window.setTimeout(function() {
											container.addClass('message-signature--expanded');
											container.css({ height: '' });
											}, 200);
											}
											}

											var hash = window.location.hash
											if (!!hash && hash.indexOf('#') === 0) {
											var replacedHash = hash.replace('#', '');
											var ele = document.getElementById(replacedHash);
											if (ele) {
											ele.scrollIntoView();
											}
											}

											/*** handle hover ***/
											

		/*** handle click ***/
		$('.uix_signatureExpand').click(function() {
		var container =  $(this).parent('.message-signature');
		expand(container, true);
		});
		}, 0);
		});
		
</script>
<script>

		$(document).ready(function() {
		setTimeout(function () { 
		var editor = XF.getEditorInContainer($(document));
		if (!!editor && !!editor.ed) {
		editor.ed.events.on('focus', function() { 
		$('.uix_fabBar').css('display', 'none');
		})
		editor.ed.events.on('blur', function() { 
		$('.uix_fabBar').css('display', '');
		})
		}
		}, 100)		
		})
	
</script>
<script>

		$(document).on('ajax:complete', function(e, xhr, status)
		{
		var data = xhr.responseJSON;
		if (!data)
		{
		return;
		}
		if (data.visitor)
		{
		$('.js-uix_badge--totalUnread').data('badge', data.visitor.total_unread);
		}
		});
	
</script>

<script src="https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js"></script>
<script>
	$(function() {
		var clipboard = new Clipboard('.xs_is_copy_token');
		clipboard.on('success', function(e) {
			e.trigger.textContent = "copied !";
		});
	});
</script>

<script>
	$(function() {
		var clipboard = new Clipboard('.xs_is_copy_code');
		clipboard.on('success', function(e) {
			e.clearSelection();
		});
	});
</script>
	
	

	


<script src="/forum/js/themehouse/io_dark/defer.min.js?_v=a146e845" defer></script>



	
<script src="/forum/js/themehouse/io_dark/deferNodesCollapse.min.js?_v=a146e845" defer></script>


	
<script src="/forum/js/themehouse/io_dark/deferWidthToggle.min.js?_v=a146e845" defer></script>





	



	




	

	

	
		
	



	

	

	

	
	
	
	
	<script>
		jQuery.extend(true, XF.config, {
			// 
			userId: 0,
			enablePush: false,
			pushAppServerKey: '',
			url: {
				fullBase: 'http://ghosted.vip/forum/',
				basePath: '/forum/',
				css: '/forum/css.php?css=__SENTINEL__&s=2&l=1&d=1654794136',
				keepAlive: '/forum/index.php?login/keep-alive'
			},
			cookie: {
				path: '/',
				domain: '',
				prefix: 'xf_',
				secure: false
			},
			cacheKey: 'b9196ed5f6440c3282c829ee5ed1811d',
			csrf: '1656157378,1c44c82087ba25f22f2656af15e319c0',
			js: {"\/forum\/js\/xf\/login_signup.min.js?_v=a146e845":true,"\/forum\/js\/xf\/notice.min.js?_v=a146e845":true,"\/forum\/js\/themehouse\/io_dark\/ripple.min.js?_v=a146e845":true,"\/forum\/js\/themehouse\/global\/20210125.min.js?_v=a146e845":true,"\/forum\/js\/themehouse\/io_dark\/index.min.js?_v=a146e845":true,"\/forum\/js\/themehouse\/io_dark\/vendor\/hover-intent\/jquery.hoverIntent.min.js?_v=a146e845":true},
			css: {"public:io.less":true,"public:iodark.less":true,"public:notices.less":true,"public:uix.less":true,"public:uix_socialMedia.less":true,"public:extra.less":true},
			time: {
				now: 1656157378,
				today: 1656111600,
				todayDow: 6,
				tomorrow: 1656198000,
				yesterday: 1656025200,
				week: 1655593200
			},
			borderSizeFeature: '2px',
			fontAwesomeWeight: 'r',
			enableRtnProtect: true,
			
			enableFormSubmitSticky: true,
			uploadMaxFilesize: 2097152,
			allowedVideoExtensions: ["m4v","mov","mp4","mp4v","mpeg","mpg","ogv","webm"],
			allowedAudioExtensions: ["mp3","opus","ogg","wav"],
			shortcodeToEmoji: true,
			visitorCounts: {
				conversations_unread: '0',
				alerts_unviewed: '0',
				total_unread: '0',
				title_count: true,
				icon_indicator: true
			},
			jsState: {},
			publicMetadataLogoUrl: '',
			publicPushBadgeUrl: 'http://ghosted.vip/forum/styles/default/xenforo/bell.png'
		});

		jQuery.extend(XF.phrases, {
			// 
			date_x_at_time_y: "{date} at {time}",
			day_x_at_time_y:  "{day} at {time}",
			yesterday_at_x:   "Yesterday at {time}",
			x_minutes_ago:    "{minutes} minutes ago",
			one_minute_ago:   "1 minute ago",
			a_moment_ago:     "A moment ago",
			today_at_x:       "Today at {time}",
			in_a_moment:      "In a moment",
			in_a_minute:      "In a minute",
			in_x_minutes:     "In {minutes} minutes",
			later_today_at_x: "Later today at {time}",
			tomorrow_at_x:    "Tomorrow at {time}",

			day0: "Sunday",
			day1: "Monday",
			day2: "Tuesday",
			day3: "Wednesday",
			day4: "Thursday",
			day5: "Friday",
			day6: "Saturday",

			dayShort0: "Sun",
			dayShort1: "Mon",
			dayShort2: "Tue",
			dayShort3: "Wed",
			dayShort4: "Thu",
			dayShort5: "Fri",
			dayShort6: "Sat",

			month0: "January",
			month1: "February",
			month2: "March",
			month3: "April",
			month4: "May",
			month5: "June",
			month6: "July",
			month7: "August",
			month8: "September",
			month9: "October",
			month10: "November",
			month11: "December",

			active_user_changed_reload_page: "The active user has changed. Reload the page for the latest version.",
			server_did_not_respond_in_time_try_again: "The server did not respond in time. Please try again.",
			oops_we_ran_into_some_problems: "Oops! We ran into some problems.",
			oops_we_ran_into_some_problems_more_details_console: "Oops! We ran into some problems. Please try again later. More error details may be in the browser console.",
			file_too_large_to_upload: "The file is too large to be uploaded.",
			uploaded_file_is_too_large_for_server_to_process: "The uploaded file is too large for the server to process.",
			files_being_uploaded_are_you_sure: "Files are still being uploaded. Are you sure you want to submit this form?",
			attach: "Attach files",
			rich_text_box: "Rich text box",
			close: "Close",
			link_copied_to_clipboard: "Link copied to clipboard.",
			text_copied_to_clipboard: "Text copied to clipboard.",
			loading: "Loading…",
			you_have_exceeded_maximum_number_of_selectable_items: "You have exceeded the maximum number of selectable items.",

			processing: "Processing",
			'processing...': "Processing…",

			showing_x_of_y_items: "Showing {count} of {total} items",
			showing_all_items: "Showing all items",
			no_items_to_display: "No items to display",

			number_button_up: "Increase",
			number_button_down: "Decrease",

			push_enable_notification_title: "Push notifications enabled successfully at Ghosted",
			push_enable_notification_body: "Thank you for enabling push notifications!"
		,
			"svStandardLib_time.day": "{count} day",
			"svStandardLib_time.days": "{count} days",
			"svStandardLib_time.hour": "{count} hour",
			"svStandardLib_time.hours": "{count} hours",
			"svStandardLib_time.minute": "{count} minutes",
			"svStandardLib_time.minutes": "{count} minutes",
			"svStandardLib_time.month": "{count} month",
			"svStandardLib_time.months": "{count} months",
			"svStandardLib_time.second": "{count} second",
			"svStandardLib_time.seconds": "{count} seconds",
			"svStandardLib_time.week": "time.week",
			"svStandardLib_time.weeks": "{count} weeks",
			"svStandardLib_time.year": "{count} year",
			"svStandardLib_time.years": "{count} years"

		});
	</script>

	<form style="display:none" hidden="hidden">
		<input type="text" name="_xfClientLoadTime" value="" id="_xfClientLoadTime" title="_xfClientLoadTime" tabindex="-1" />
	</form>

	

		
		
			<script type="text/template" id="xfReactTooltipTemplate">
			<div class="tooltip-content-inner">
				<div class="reactTooltip">
					
						<a href="#" class="reaction reaction--1" data-reaction-id="1"><i aria-hidden="true"></i><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="reaction-sprite js-reaction" alt="Like" title="Like" data-xf-init="tooltip" data-extra-class="tooltip--basic tooltip--noninteractive" /></a>
				
						<a href="#" class="reaction reaction--2" data-reaction-id="2"><i aria-hidden="true"></i><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="reaction-sprite js-reaction" alt="Love" title="Love" data-xf-init="tooltip" data-extra-class="tooltip--basic tooltip--noninteractive" /></a>
				
						<a href="#" class="reaction reaction--3" data-reaction-id="3"><i aria-hidden="true"></i><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="reaction-sprite js-reaction" alt="Haha" title="Haha" data-xf-init="tooltip" data-extra-class="tooltip--basic tooltip--noninteractive" /></a>
				
						<a href="#" class="reaction reaction--4" data-reaction-id="4"><i aria-hidden="true"></i><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="reaction-sprite js-reaction" alt="Wow" title="Wow" data-xf-init="tooltip" data-extra-class="tooltip--basic tooltip--noninteractive" /></a>
				
						<a href="#" class="reaction reaction--5" data-reaction-id="5"><i aria-hidden="true"></i><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="reaction-sprite js-reaction" alt="Sad" title="Sad" data-xf-init="tooltip" data-extra-class="tooltip--basic tooltip--noninteractive" /></a>
				
						<a href="#" class="reaction reaction--6" data-reaction-id="6"><i aria-hidden="true"></i><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="reaction-sprite js-reaction" alt="Angry" title="Angry" data-xf-init="tooltip" data-extra-class="tooltip--basic tooltip--noninteractive" /></a>
				
				</div>
				</div>
			</script>
		

		

		

	</body>
</html>





